    ofList = [16]
    ksList = [5]
    for of in ofList:
        for ks in ksList:
            AnaTrain(load=False,oft=of , k_s=ks)